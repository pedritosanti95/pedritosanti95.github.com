package pedro;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

public class QuizServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession s  = request.getSession();
        int answer = Integer.parseInt(request.getParameter("result"));
        QuizLogic quiz;

        if(s.getAttribute("quiz")==null || answer==0) s.setAttribute("quiz", new QuizLogic());
        quiz = (QuizLogic) s.getAttribute("quiz");
        if(answer!=0 && quiz.getCurr()!=4) quiz.next(answer,quiz.getCurr());

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.print("<html><head><title>Quiz</title></head><body>" +
                "<h1>The Number Quiz</h1>\n");
        if(quiz.getCurr()!=4)
        out.print("<p> Don't give up. You are on question "+(quiz.getCurr()+1)+"/5</p>\n" +
                "<p> Your current score: "+quiz.getScore()+"</p>\n" +
                "<p>Can you guess the next number in the sequence?</p>\n" +
                "<p> "+quiz.getQuestion(quiz.getCurr())+"</p>" +
                "<form action=\"QuizServlet\" method=\"post\">\n" +
                "   <p>Your Answer: <input type=\"number\" name=\"result\" min=1 max=99999 required/></p>\n" +
                "   <input type=\"submit\"/>\n" +
                "</form>" +
                "</body></html>");
        else{
            int score = quiz.getScore();
            s.removeAttribute("quiz");
            out.print("<p>The quiz is over. Your final score is "+score+"/5. Try again?</p>" +
                    "<form action=\"QuizServlet\" method=\"post\">\n" +
                    "   <input type=\"hidden\" name=\"result\" value=\"0\"/>\n" +
                    "   <input type=\"submit\"/>\n" +
                    "</form>" + "</body></html>");
        }
    }
}

package pedro;

public class QuizLogic {
    private int score;
    private int curr;
    private final String[] questions = {
            "2,4,8,16,32",
            "8,13,21,34,55",
            "12,25,51,103,207",
            "1,7,66,655,6544",
            "7,24,41,58,75",
    };
    private final int[] answers = {64, 89, 415, 65433, 92};

    public QuizLogic(){
        this.score = 0;
        this.curr = 0;
    }

    public void next(int ans, int idx){
        score += ans == answers[idx]? 1 : 0;
        curr++;
    }

    public int getCurr(){ return curr; }

    public int getScore(){ return score; }

    public String getQuestion(int i){ return questions[i]; }
}

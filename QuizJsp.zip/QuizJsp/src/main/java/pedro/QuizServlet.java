package pedro;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

public class QuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession s  = request.getSession();
        String ans = request.getParameter("result");
        int answer = ans==null || ans.equals("")? 0 : Integer.parseInt(ans);
        QuizLogic quiz;

        if(s.getAttribute("quiz")==null || answer==0) s.setAttribute("quiz", new QuizLogic());
        quiz = (QuizLogic) s.getAttribute("quiz");
        if(answer!=0 && quiz.getCurr()!=5) quiz.next(answer,quiz.getCurr());
        //
        if(quiz.getCurr()==5)
            request.getRequestDispatcher("quizOver.jsp").forward(request,response);
        else request.getRequestDispatcher("index.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}

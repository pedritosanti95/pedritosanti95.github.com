package pedro.salazar;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

public class Calc extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //GETTING CALCULATIONS
        String s1 = request.getParameter("n1");
        String s2 = request.getParameter("n2");
        String s3 = request.getParameter("n3");
        String s4 = request.getParameter("n4");
        //Integer min = Integer.MIN_VALUE;
        Integer n1 = Integer.parseInt(s1),
                n2 = Integer.parseInt(s2),
                n3 = Integer.parseInt(s3),
                n4 = Integer.parseInt(s4);
                //n4 = s4.chars().allMatch(Character::isDigit) ? Integer.parseInt(s4) : min;
        String r1 = Integer.toString(n1+n2),
               r2 = Integer.toString(n3*n4);
               //r2 = n3.equals(min) || n4.equals(min) ? "" : Integer.toString(n3*n4);

        //RETURNING VALUES
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.print("<html><head>" +
                "<style>\n" +
                "   .order{\n" +
                "      display: block;\n" +
                "      margin: 5px;\n" +
                "   }\n" +
                "   input[type=number]{\n" +
                "       width: 60px;\n" +
                "   } " +
                "</style>" +
                "<title>Result</title></head><body>");
        out.print("<h2>Calculator App</h2>\n" +
                "    <form action=\"Calc\" method=\"GET\">\n" +
                "        <span class=\"order\">\n" +
                "            <input type=\"number\" name=\"n1\" value=\""+s1+"\" placeholder=\"0\" size=\"3\" maxlength=\"3\" required/>+\n" +
                "            <input type=\"number\" name=\"n2\" value=\""+s2+"\" placeholder=\"0\" size=\"3\" maxlength=\"3\" required/>=\n" +
                "            <input type=\"text\" name=\"r1\" value=\""+r1+"\" size=\"5\" disabled/>\n" +
                "        </span>\n" +
                "        <span class=\"order\">\n" +
                "            <input type=\"number\" name=\"n3\" value=\""+s3+"\" placeholder=\"0\" size=\"3\" maxlength=\"3\" required/>*\n" +
                "            <input type=\"number\" name=\"n4\" value=\""+s4+"\" placeholder=\"0\" size=\"3\" maxlength=\"3\" required/>=\n" +
                "            <input type=\"number\" name=\"r2\" value=\""+r2+"\" size=\"5\" disabled/>\n" +
                "        </span>\n" +
                "        <input type=\"submit\"/>\n" +
                "    </form>");
        out.print("</body></html>");

        out.close();
    }
}
